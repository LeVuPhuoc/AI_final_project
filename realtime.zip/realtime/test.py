import tensorflow as tf
import imutils
import numpy as np
import cv2
import argparse
from time import time
from imutils.object_detection import non_max_suppression
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model


ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", default = "/content/gdrive/MyDrive/Colab Notebooks/AI/valid_flowers/carnation/1314752606_d428e17659_c.jpg", #required=False,
    help="path to the input image")
ap.add_argument("-s", "--size", type=str, default="(200, 150)",
    help="ROI size (in pixels)")
ap.add_argument("-c", "--min-conf", type=float, default=0.7,
    help="minimum probability to filter weak detections")
ap.add_argument("-v", "--visualize", type=int, default=1,
    help="whether or not to show extra visualizations for debugging")
args = vars(ap.parse_args([]))

# initialize variables used for the object detection procedure
WIDTH = 600 # 
PYR_SCALE = 1.5
WIN_STEP = 16*3 # running on laptop so I generated a small pyramid
ROI_SIZE = eval(args["size"])
INPUT_SIZE = (224, 224) # input of resnet model.summary()
model = load_model('model_acc_0.7066511511802673.h5')
def sliding_window(image, step, ws):
    #slide a window of ws size over the image
    for y in range(0, image.shape[0]-ws[1], step): # rows-wise loop
        # -ws[1] avoids extending the sliding window outside the image itself, increment the y-position with step
        for x in range(0, image.shape[1] - ws[0], step):#columns-wise loop, increment the x-position with step
            # use yield(instead of return) because this is a generator
            #yield the actual x and y positions and the current window
            yield (x, y, image[y:y + ws[1], x:x + ws[0]]) 

def image_pyramid(image, scale=1.5, minSize=(224, 224)):
    # yield the original image, this is the base of the image pyramid
    yield image
    # keep looping over the image pyramid
    while True:
        # compute the dimensions of the next image in the pyramid
        #scale controls how much the image is resized at each layer
        w = int(image.shape[1] / scale)
        # resize the image and take care of image aspect-ratio
        image = imutils.resize(image, width=w) 
        # if the resized image does not meet the supplied minimum
        # size, then stop constructing the pyramid
        if image.shape[0] < minSize[1] or image.shape[1] < minSize[0]:
            break
        # yield the next image in the pyramid
        yield image

def real_time(image):
    # resize  image- note that it doesn not fit the input to ResNet50
    orig = image
    orig = imutils.resize(orig, width = WIDTH)
    (H, W) = orig.shape[:2] # 800, 600
    # initialize the image pyramid
    pyramid = image_pyramid(orig, scale=PYR_SCALE, minSize=ROI_SIZE)
    # initialize two lists, one to hold the ROIs generated from the image pyramid 
    #and sliding window, and another list used to store the
    # (x, y)-coordinates of where the ROI was in the original image
    rois = []
    locs = []
    # time how long it takes to loop over the image pyramid layers and
    # sliding window locations
    #start = time.time()
    counter = 0
    tot_images = 0
    for p, image in enumerate(pyramid):
        # determine the scale factor between the *original* image
        # dimensions and the *current* layer of the pyramid
        scale = W / float(image.shape[1])
        # for each layer of the image pyramid, loop over the sliding
        # window locations
        sw = 0
        for (x, y, roiOrig) in sliding_window(image, WIN_STEP, ROI_SIZE):
            sw = sw + 1
            # scale the (x, y)-coordinates of the ROI with respect to the
            # *original* image dimensions
            x = int(x * scale)
            y = int(y * scale)
            w = int(ROI_SIZE[0] * scale)
            h = int(ROI_SIZE[1] * scale)
            # take the ROI and pre-process it so we can later classify
            # the region using Keras/TensorFlow
            roi = cv2.resize(roiOrig, INPUT_SIZE)
            roi = tf.keras.preprocessing.image.img_to_array(roi)
            roi = tf.keras.applications.resnet.preprocess_input(roi)
            #print(roiOrig.shape, roi.shape)
            # update our list of ROIs and associated coordinates
            rois.append(roi)
            locs.append((x, y, x + w, y + h))
            # check to see if we are visualizing each of the sliding
            # windows in the image pyramid
            if 1 > 0:
                # clone the original image and then draw a bounding box
                # surrounding the current region
                clone = orig.copy()
                cv2.rectangle(clone, (x, y), (x + w, y + h),(0, 255, 0), 5)
                # show the visualization and current ROI
                #plt.imshow(clone)
                #var_name = "p" + str(p)+"_" + "sw" + str(sw) + ".jpg"
                #plt.savefig("images/clone_"+ var_name)
                #plt.imshow(roiOrig)
                #plt.savefig("images/roiOrig_"+ var_name)
                #cv2.waitKey(0)
                tot_images = tot_images +1
    print(roiOrig.shape, roi.shape)
    # show how long it took to loop over the image pyramid layers and
    # sliding window locations
    #end = time.time()
    #print("[INFO] looping over pyramid/windows took {:.5f} seconds".format(end - start))
    print("Total images {:.2f}".format(tot_images))
    
    # convert the ROIs to a NumPy array
    rois = np.array(rois, dtype="float32")
    # classify each of the proposal ROIs using ResNet and then show how
    # long the classifications took
    print("[INFO] classifying ROIs...")
    #start = time.time()
    my_preds = model.predict(rois)
    #end = time.time()
    #print("[INFO] classifying ROIs took {:.5f} seconds".format(end - start))

    my_preds[0]
    np.argmax(my_preds[1])
    # len(my_preds)
    labels_name = ['astilbe', 'bellflower', 'califonia_poppy', 'carnation', 'common_daisy', 'coreopsis', 'daffodil', 'daisy', 'dandelion', 'iris', 'magnolia', 'rose', 'sunflower', 'tulip', 'water_lily']
    print(len(labels_name))
    preds = []
    for i in range(len(my_preds)):
        label = labels_name[np.argmax(my_preds[i])]
        prob = max(my_preds[i])
        pred = (label, prob)
        preds.append(pred)
        # # preds = 
        # print('---')
        # print(my_preds[i])
        # print(prob)
    
    for (i, p) in enumerate(preds):
        (label, prob) = p
        print(label, prob)

    # decode the predictions and initialize a dictionary which maps class
    # labels (keys) to any ROIs associated with that label (values)
    #preds = tf.keras.applications.imagenet_utils.decode_predictions(my_preds, top=1)
    labels = {}
    #probs = {}
    # loop over the predictions
    for (i, p) in enumerate(preds):
        # grab the prediction information for the current ROI
        (label, prob) = p#[0]
        # filter out weak detections by ensuring the predicted probability
        # is greater than the minimum probability
        if prob >= 0.7:
            # grab the bounding box associated with the prediction and
            # convert the coordinates
            box = locs[i]

            # grab the list of predictions for the label and add the
            # bounding box and probability to the list
            L = labels.get(label, [])
            L.append((box, prob))
            labels[label] = L

    
    # loop over the labels for each of detected objects in the image
    allclone = orig.copy()
    for label in labels.keys():
        # clone the original image so that we can draw on it
        print("[INFO] showing results for '{}'".format(label))
        clone = orig.copy()

        # loop over all bounding boxes for the current label
        for (box, prob) in labels[label]:
            # draw the bounding box on the image
            (startX, startY, endX, endY) = box
            cv2.rectangle(clone, (startX, startY), (endX, endY),(0, 255, 0), 2)

        # show the results *before* applying non-maxima suppression, then
        # clone the image again so we can display the results *after*
        # applying non-maxima suppression
        #plt.imshow(clone)
        #cv2.imshow("Before", clone)
        clone = orig.copy()

        # extract the bounding boxes and associated prediction
        # probabilities, then apply non-maxima suppression
        boxes = np.array([p[0] for p in labels[label]])
        proba = np.array([p[1] for p in labels[label]])
        boxes = non_max_suppression(boxes, proba)
        print("len: ", len(boxes))
        # loop over all bounding boxes that were kept after applying
        # non-maxima suppression
        for (startX, startY, endX, endY) in boxes:
            # draw the bounding box and label on the image
            cv2.rectangle(clone, (startX, startY), (endX, endY),(0, 255, 0), 2)
            cv2.rectangle(allclone, (startX, startY), (endX, endY),(0, 255, 0), 2)
            y = startY - 10 if startY - 10 > 10 else startY + 10
            
            # print('clone: ', clone)
            cv2.putText(clone, str(label), (startX, y+30),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(clone, "{:.2f}".format(prob), (startX, y),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(allclone, str(label), (startX, y+30),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(allclone, "{:.2f}".format(prob), (startX, y),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)        
        # show the output after apply non-maxima suppression
    #     plt.imshow(clone)
    #     plt.imsave("images/_res03_" + str(label) + ".jpg", clone) 
    # plt.imshow(allclone)
    # plt.imsave("images/_allclone03.jpg", allclone)     
    return allclone


video = cv2.VideoCapture('Video về các loài hoa.webm')
length = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
i = 0
while True:
    ret, frame = video.read()
    
    if ret == False:
        break
    if  i >= 50*30:
        frame = real_time(frame)
        cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    if i == length:
        break
    i += 1
video.release()
cv2.destroyAllWindows()
